// get the first .artist and change the innerHTML to your name

// add the className new-class

// add the className highlight

// Loop through to add bright class on all artists
