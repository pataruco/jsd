const mainHeading = document.createElement('h1');
mainHeading.innerHTML = 'Reminders';
document.querySelector('header').appendChild(mainHeading);
