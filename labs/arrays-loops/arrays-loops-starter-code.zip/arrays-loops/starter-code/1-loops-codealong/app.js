// console.log('working!');

// const myArray = ['one', 'two', 'three', 'four', 'five'];

// const thingsInMyFridge = ['pizza', 'eggs', 'milk', 'beers', 'ketchup'];
// console.log(thingsInMyFridge);

// myArray.push('six');
// thingsInMyFridge.push('chicken')
// console.log(thingsInMyFridge);

// console.log(myArray);

// myArray.unshift('zero');
// thingsInMyFridge.unshift('veg')
// console.log(thingsInMyFridge)

// thingsInMyFridge.pop()
// console.log(thingsInMyFridge)

// thingsInMyFridge.shift()
// console.log(thingsInMyFridge)

// const middle = thingsInMyFridge.splice(1, 2)

// console.log({middle})

// console.log({thingsInMyFridge})

// console.log(myArray);

// declare an initial value
// if the value to check returns true, increment the value by 1 and do something...

// for (let i = 0; i <= myArray.length; i++) {
//   console.log(myArray[i].toUpperCase());
// }

const countArray = [1, 2, 3, 4, 5, 6, 7, 8];

for (let i = 0; i < countArray.length; i++) {
  console.log(countArray[i])
}


// for (let i = 0; i < countArray.length; i++) {
//   if(i === 3) {
//     console.log('four!');
//   } else if (i === 7) {
//     console.log('more!');
//   } else {
//     console.log(`${countArray[i]} potato`);
//   }
// }
