console.log('working!');

const numbersNames = ['one', 'two', 'three', 'four', 'five'];

const thingsInMyFridge = ['pizza', 'eggs', 'milk', 'beers', 'ketchup'];

/**
 * .push
 */
// code here

/**
 * .unshift
 */
// code here

/**
 * .pop
 */
// code here

/**
 * .shift
 */
// code here

/**
 * .splice
 */
// code here

/**
 * .for
 */
// code here
