console.log('We have just run our first Node.js program!');

const students = 18;

const instructors = 3;

console.log(
  `JSD12 has ${students + instructors} lovely people in the class :)`,
);
