# Command line code along

## Task:

Use your terminal to navigate your computers file structure.

1. Navigate to the desktop
2. Create a directory called `films`
3. Go into this directory
4. Create a file for your favourite film called `[FILM NAME].txt`
5. Open this file in VSCode
6. Create 3 more files using a single terminal command
7. Open the entire directory inside VSCode so you can see all 4 files and make some changes (remember to save the changes)
8. Delete your least 2 favourite films
