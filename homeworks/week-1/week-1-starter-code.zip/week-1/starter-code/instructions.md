# Week 1 Homework

## Task:

1. Complete the tasks in the javascript file by using a Node.js REPL to see the results

2. Push your code to your own branch of the homework repository

## To create your own git branch

- Navigate to the root of the homework folder
- In your terminal, type `git checkout -b YOUR-BRANCH-NAME`

branch names can not have spaces

## Remember

To commit and push your code, you must:

- `git add .`
- `git commit -m 'add your commit message here in single quotes'`
- `git push`
